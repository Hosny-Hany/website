$(document).ready(function() {
  // Show alert when any element with the class "buy-now" is clicked
  $('.buy-now').click(function() {
    alert("Thank you for your purchase!");
  });

  // Smooth scrolling to sections when a link is clicked
  $('a[href^="#"]').click(function(e) {
    // e.preventDefault();
    var target = $(this).attr('href');
    $('html, body').animate({
      scrollTop: $(target).offset().top
    }, 1500);
  });

  // Toggle navigation menu on small screens
  // $('.menu-toggle').click(function() {
  //   $('nav ul').toggleClass('show');
  // });

  // Validate and submit the contact form
  $('#contact-form').submit(function(e) {
    e.preventDefault();
    var name = $('#name').val();
    var email = $('#email').val();
    var message = $('#message').val();

    if (name === '' || email === '' || message === '') {
      alert('Please fill in all fields.');
    } else {
      // Simulate form submission (replace with your own logic)
      alert('Thank you for contacting us! We will get back to you soon.');
      $('#contact-form')[0].reset(); // Reset the form fields
    }
  });
});